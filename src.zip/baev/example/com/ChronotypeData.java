package baev.example.com;

public class ChronotypeData {
    public String chronotype;
    public double gaussMark;
    public double depressionMark;
    public double positiveSmiles;
    public double negativeSmiles;
    public double coffee;
    public double night;
    public double morning;
    public double sleep;
    public double dog;
    public double rt;
    public double fat;
    public double med;
    public int tweets;
    double[] times;


    public ChronotypeData() {
        chronotype = "";
        positiveSmiles = 0;
        negativeSmiles = 0;
        coffee = 0;
        night = 0;
        morning = 0;
        sleep = 0;
        dog = 0;
        rt = 0;
        fat = 0;
        med = 0;
        tweets = 0;
        times = new double[400];
    }
}
