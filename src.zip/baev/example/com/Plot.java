package baev.example.com;

import javafx.util.Pair;
import org.math.plot.Plot2DPanel;
import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;

import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;
import java.util.List;

public class Plot {

    public static double calcCorrelation(double[] a, double[] b, int size) {
        double n = size;
        double expA = 0;
        double expB = 0;
        for (int i = 0; i < n; i++) {
            expA += a[i];
            expB += b[i];
        }
        expA /= n;
        expB /= n;
        double dispA = 0;
        double dispB = 0;
        double cov = 0;
        for (int i = 0; i < n; i++) {
            cov += (a[i] - expA) * (b[i] - expB);
            dispA += Math.pow(a[i] - expA, 2.0);
            dispB += Math.pow(b[i] - expB, 2.0);
        }
        dispA /= n;
        dispB /= n;
        cov /= n;

        return cov / Math.sqrt(dispA) / Math.sqrt(dispB);
    }

    public static int countOcc(String t, String p) {
        int ans = 0;
        int lastIndex = 0;
        while (lastIndex != -1) {
            lastIndex = t.indexOf(p, lastIndex);
            if (lastIndex != -1) {
                ans++;
                lastIndex += p.length();
            }
        }
        return ans;
    }

    public static int addBool(boolean b) {
        return b ? 1 : 0;
    }

    public static void main(String[] args) throws IOException, TwitterException {
        BufferedReader in = new BufferedReader(new FileReader("tweets_time_hypothess.txt"));
        BufferedReader in_users = new BufferedReader(new FileReader("users_id_chr.txt"));

        PrintWriter out = new PrintWriter("temp.txt");

        BufferedReader deprIn = new BufferedReader(new FileReader("depr.txt"));


        Set<String> depressive = new HashSet<>();
        for (int i = 0; i < 191; i++) {
            depressive.add(deprIn.readLine());
        }
        depressive.add("depress");
        depressive.add("anxi");
        depressive.add("alone");
        depressive.add("nervous");
        depressive.add("pain");
        depressive.add("sad");
        depressive.add("psychos");
        depressive.add("pessimist");
        depressive.add("insomni");
        depressive.add("suicid");
        depressive.add("passiv");
        depressive.add("tired");
        depressive.add("�������");
        depressive.add("����������");
        depressive.add("�����");
        depressive.add("����");
        depressive.add("���");
        depressive.add("����");
        depressive.add("�����");
        depressive.add("��������");
        depressive.add("��������");
        depressive.add("������");
        depressive.add("������");
        depressive.add("����");


        int users = 230;
        int lines = 70586;

        Map<Long, Integer> getIndex = new HashMap<>();
        Twitter twitter = new TwitterFactory().getInstance();

        ChronotypeData[] data = new ChronotypeData[users];
        for (int i = 0; i < users; i++) {
            //System.out.println("api call: " + i);
            data[i] = new ChronotypeData();
            String s = in_users.readLine();
            String[] ss = s.split("\t");
            String chronotype = ss[2];
            long userId = Long.valueOf(ss[0]);
            Integer index = getIndex.get(userId);
            if (index == null) {
                getIndex.put(userId, getIndex.size());
                index = getIndex.size() - 1;
            }
            data[index].chronotype = chronotype;

        }


        for (int i = 0; i < lines; i++) {
            if (i % 1000 == 0) {
                System.out.println(i);
            }
            String s = in.readLine();
            String[] ss = s.split(" ");
            //System.out.println(i);
            Long userId = Long.valueOf(ss[0]);
            Integer index = getIndex.get(userId);
            if (index == null) {
                getIndex.put(userId, getIndex.size());
                index = getIndex.size() - 1;
            }
            if (data[index].tweets == 400) {
                continue;
            }
            String[] parts = ss[4].split(":");
            double val = Double.valueOf(parts[0]) + Double.valueOf(parts[1]) / 60;
            data[index].times[data[index].tweets] = val / 24;
            data[index].tweets++;
            String msg = s.substring(s.indexOf('$'));
            for (String cur : depressive) {
                data[index].depressionMark += countOcc(msg, cur);
            }
            data[index].positiveSmiles += countOcc(msg, ":)");
            data[index].positiveSmiles += countOcc(msg, ":-)");
            data[index].positiveSmiles += countOcc(msg, ":))");
            data[index].positiveSmiles += countOcc(msg, ")))");
            data[index].positiveSmiles += countOcc(msg, "))");
            data[index].positiveSmiles += countOcc(msg, ":D");
            data[index].positiveSmiles += countOcc(msg, "xD");
            data[index].positiveSmiles += countOcc(msg, "ha");
            data[index].positiveSmiles += countOcc(msg, "good");
            data[index].positiveSmiles += countOcc(msg, "happy");
            data[index].positiveSmiles += countOcc(msg, "��");
            data[index].positiveSmiles += countOcc(msg, "�����");
            data[index].positiveSmiles += countOcc(msg, "�����");
            data[index].negativeSmiles += countOcc(msg, ":(");
            data[index].negativeSmiles += countOcc(msg, ":'(");
            data[index].negativeSmiles += countOcc(msg, "t_t");
            data[index].negativeSmiles += countOcc(msg, ":-(");
            data[index].negativeSmiles += countOcc(msg, ":((");
            data[index].negativeSmiles += countOcc(msg, "(((");
            data[index].negativeSmiles += countOcc(msg, "((");
            data[index].negativeSmiles += countOcc(msg, "cry");
            data[index].negativeSmiles += countOcc(msg, "bad");
            data[index].negativeSmiles += countOcc(msg, "����");
            data[index].negativeSmiles += countOcc(msg, "����");
            data[index].night += countOcc(msg, "night");
            data[index].morning += countOcc(msg, "morning");
            data[index].coffee += countOcc(msg, "coffee");
            data[index].coffee += countOcc(msg, "caffe");
            data[index].coffee += countOcc(msg, "espress");
            data[index].coffee += countOcc(msg, "arabic");
            data[index].coffee += countOcc(msg, "energetic");
            data[index].sleep += countOcc(msg, "sleep");


            data[index].night += countOcc(msg, "���");
            data[index].morning += countOcc(msg, "���");
            data[index].coffee += countOcc(msg, "����");
            data[index].coffee += countOcc(msg, "����");
            data[index].coffee += countOcc(msg, "�������");
            data[index].coffee += countOcc(msg, "������");
            data[index].coffee += countOcc(msg, "��������");
            data[index].sleep += countOcc(msg, "���");
            data[index].sleep += countOcc(msg, "����");
            data[index].dog += countOcc(msg, "@");
            data[index].rt += countOcc(msg, "rt");

            data[index].fat += countOcc(msg, "weight");
            data[index].fat += countOcc(msg, "food");
            data[index].fat += countOcc(msg, "fat");
            data[index].fat += countOcc(msg, "���");
            data[index].fat += countOcc(msg, "���");
            data[index].fat += countOcc(msg, "���");
            data[index].fat += countOcc(msg, "���");
            data[index].fat += countOcc(msg, "�����");


            data[index].med += countOcc(msg, "antidepressant");
            data[index].med += countOcc(msg, "psychotherap");
            data[index].med += countOcc(msg, "drugs");
            data[index].med += countOcc(msg, "alcohol");
            data[index].med += countOcc(msg, "smok");
            data[index].med += countOcc(msg, "������������");
            data[index].med += countOcc(msg, "����������");
            data[index].med += countOcc(msg, "������");
            data[index].med += countOcc(msg, "�������");
            data[index].med += countOcc(msg, "�����");
            data[index].med += countOcc(msg, "�����");

        }

        int owlCount = 0;
        int notOwlCount = 0;
        int algoOwlCount = 0;
        int algoNotOwlCount = 0;
        int deprCount = 0;
        int notDeprCount = 0;
        int nightCount = 0;
        int notNightCount = 0;
        out.println("depress,posSmile,negSmile,coffee,night,morning,sleep,fat,med,total,chronotype");

        int owls = 0;
        int larks = 0;
        int mixed = 0;
        double owlsSum = 0;
        double larksSum = 0;
        double mixedSum = 0;

        double tp = 0;
        double fp = 0;
        double fn = 0;

        double[] gaussVal = new double[getIndex.size()];
        double[] realVal = new double[getIndex.size()];

        int gaussSize = 0;

        for (int i = 0; i < getIndex.size(); i++) {
            if (data[i].tweets == 0) {
                continue;
            }
            System.out.println("user #" + i);
            List<Pair<Double, Double>> ans = GaussianMixture.calculate(data[i].times, data[i].tweets, 50, 2);
//            System.out.println();
            double[] t = new double[24];
            int bestTime = -1;
            int bestCount = 0;
            //out.print(data[i].chronotype + " " + data[i].tweets + " ");
            for (int id = 0; id < 24; id++) {
                int count = 0;
                for (int j = 0; j < data[i].tweets; j++) {
                    double val = data[i].times[j] * 24.0;
                    if (val >= id && val < (id + 0.99)) {
                        count++;
                    }
                }
                //out.print(count + " ");
                t[id] = count;
                //if (data[i].chronotype.equals("mixed"))
//                    System.out.println("id " + id + ": " + t[id]);
                if (count > bestCount) {
                    bestCount = count;
                    bestTime = id;
                }
            }
            //out.println();
            int n1 = (int) (ans.get(0).getKey() * 24.0);
            int n2 = (int) (ans.get(1).getKey() * 24.0);
            if (n1 > 22 || n1 < 4) {
                int gg = n1;
                n1 = n2;
                n2 = gg;
            }
//            bestTime = t[n1] > t[n2] ? n1 : n2;
//            out.print(bestTime + ",               ");
            if (bestTime > 17 || bestTime < 5) {
//            if (n2 < 5 || n2 > 22) {
//          if ((n1 > 4 && n1 < 10) || (n2 > 4 && n2 < 10)) {
                bestTime = 1;
            } else {
                bestTime = 0;
            }
            String class_ans = bestTime == 0 ? "lark" : "owl";
            out.println(data[i].depressionMark / data[i].tweets + ","
                    + data[i].positiveSmiles / data[i].tweets + "," + data[i].negativeSmiles / data[i].tweets + ","
                    + data[i].coffee / data[i].tweets + ","
                    + data[i].night / data[i].tweets + "," + data[i].morning / data[i].tweets + "," + data[i].sleep / data[i].tweets + ","
                    + data[i].fat / data[i].tweets + "," + data[i].med / data[i].tweets + ","
                    + data[i].tweets + "," + data[i].chronotype);


            double chr = data[i].chronotype.equals("lark") ? 0 : 1;
            gaussVal[gaussSize] = data[i].chronotype.equals("owl") ? 1 : 0;
            realVal[gaussSize] = data[i].chronotype.equals("owl") ? 0 : 1;
            gaussSize++;


//            out.println(n1 + "," + n2 + "," + chr);
            if (chr == bestTime) {
//                out.print("OK ");
            }
//            out.println("chr: " + chr + " gaus: " + bestTime + " n1: "
//                    + n1 + " n2: " + n2);

            double owlPerc = 0;
            double larkPerc = 0;
            double mixedperc = 0;
            for (int id = 5; id < 10; id++) {
                larkPerc += t[id];
            }
            for (int id = 23; id < 24; id++) {
                owlPerc += t[id];
            }
            for (int id = 0; id < 5; id++) {
                owlPerc += t[id];
            }
            larkPerc /= data[i].tweets;
            owlPerc /= data[i].tweets;


            //bestTime = t[n1] > t[n2] ? n1 : n2;
            //if (bestTime < 7)
            //bestTime += 24;

            if (data[i].chronotype.equals("owl")) {
                owls++;
                owlsSum += bestTime;
//                System.out.print(larkPerc + " ");
                if (owlPerc >= 0.2) {
//                    System.out.print("!owl ");
                } else {
//                    System.out.print("owl ");
                }
//                System.out.println();
//                System.out.println(bestTime);
            } else if (data[i].chronotype.equals("lark")) {
                larks++;
                larksSum += bestTime;
//                System.out.print("la / ow: " + (larkPerc / owlPerc) + "; ");
//                System.out.print("la: " + larkPerc + "; ");
                if (owlPerc < 0.25) {
//                    System.out.print("!lark ");
                } else {
//                    System.out.print("lark ");
                }
//                System.out.println(bestTime);
            } else if (data[i].chronotype.equals("mixed")) {
                mixed++;
                mixedSum += bestTime;
//                System.out.print("mixed ");
            }
            //System.out.println(bestTime);


            //data[i].gaussMark = bestTime;
            data[i].gaussMark = ((bestTime > 4) && (bestTime < 18)) ? 0 : 1;
            //int bestId = ans.get(1).getValue() < ans.get(0).getValue() ? 1 : 0;
            //data[i].gaussMark = (ans.get(bestId).getKey() > 0.16) && (ans.get(bestId).getKey() < 0.5) ? 0 : 1;
            boolean depr = data[i].depressionMark > 10;
            boolean negSmile = (data[i].negativeSmiles - data[i].positiveSmiles) > 0;
            boolean coffee = data[i].coffee > 5;
            boolean sleep = data[i].sleep > 2;
            boolean night = (data[i].night - data[i].morning + 1) > 5;
            boolean owl = data[i].gaussMark == 1;

            double res = 0;
            res += 0.5 * addBool(depr);
            res += addBool(negSmile);
            //res += addBool(coffee);
            res += addBool(sleep);
            res += 0.5 * addBool(night);


            /*System.out.println("owl: " + (data[i].gaussMark == 1) + "\tclassif: " + res + "\ttweets: "
                    + data[i].tweets + "\tdepress: " +
                    data[i].depressionMark + "\tneg smile: " + (data[i].negativeSmiles - data[i].positiveSmiles) +
                    "\tcoffee: " + data[i].coffee +
                    "\tsleep: " + data[i].sleep + "\tnight: " + (data[i].night - data[i].morning + 1));
             */

            if (owl)
                owlCount++;
            else
                notOwlCount++;
            if (res > 0.4)
                algoOwlCount++;
            else
                algoNotOwlCount++;

            boolean algoOwl = res > 0.4;
            if (owl == algoOwl && owl)
                tp++;
            if (owl != algoOwl && algoOwl)
                fp++;
            if (owl != algoOwl && !algoOwl)
                fn++;

            if (owl && depr)
                deprCount++;
            if (!owl && !depr)
                notDeprCount++;
            if (owl && night)
                nightCount++;
            if (!owl && !night)
                notNightCount++;



            /*System.out.println("owl: " + owl + "\tdepress: " +
                    depr + "\tneg smile: " + negSmile +
                    "\tcoffee: " + coffee +
                    "\tsleep: " + sleep + "\tnight: " + night);
             */
        }

        Random rand = new Random();
        for (int i = 0; i < gaussSize; i++) {
            realVal[i] = gaussVal[i] + Math.random() * 2;
        }

        System.out.println("Correlation: " + Plot.calcCorrelation(gaussVal, realVal, gaussSize));

        out.close();

        double owlAvg = owlsSum / owls;
        double larkAvg = larksSum / larks;
        double mixedAvg = mixedSum / mixed;
//        System.out.println("owlAvg: " + owlAvg + " owls: " + owls);
//        System.out.println("larkAvg: " + larkAvg + " larks: " + larks);
//        System.out.println("mixedAvg: " + mixedAvg + " mixed: " + mixed);

        double prec = tp / (tp + fp);
        double recall = tp / (tp + fn);
        /*System.out.println("prec: " + (tp / (tp + fp)));
        System.out.println("recall: " + (tp / (tp + fn)));
        System.out.println("F1: " + (2 * prec * recall / (prec + recall)));
        System.out.println("Owls: " + owlCount);
        System.out.println("larks: " + notOwlCount);
        System.out.println("algo Owls: " + algoOwlCount);
        System.out.println("algo larks: " + algoNotOwlCount);
        System.out.println("depr Owls: " + deprCount);
        System.out.println("notdepr larks: " + notDeprCount);
        System.out.println("night owls: " + nightCount);
        System.out.println("morning larks: " + notNightCount);
        */

        in.close();
        in = new BufferedReader(new FileReader("Tweets.txt"));
        Plot2DPanel plot = new Plot2DPanel();
        double[] x = new double[3189];
        double[] y = new double[3189];
        Arrays.fill(y, 0);


        for (int i = 0; i < 3189; i++) {
            String time = in.readLine().split(" ")[4];
            String[] parts = time.split(":");
            double val = Double.valueOf(parts[0]) + Double.valueOf(parts[1]) / 60;
            x[i] = val;
        }

        Arrays.sort(x);
        double[] t = new double[24];

        double minValue = Double.MAX_VALUE;
        int minId = 0;

        for (int i = 0; i < 24; i++) {
            int count = 0;
            for (int j = 0; j < 3189; j++) {
                if (x[j] >= i && x[j] < (i + 0.99)) {
                    count++;
                }
            }
            t[i] = count;
            if (t[i] < minValue) {
                minValue = t[i];
                minId = i;
            }
//            System.out.println(i + ": " + count);
        }
//        System.out.println("minId: " + minId);

        double[] x2 = Arrays.copyOf(x, 3189);

        for (int i = 0; i < 3189; i++) {
            int gg = (int) Math.round(x[i]);
            if (gg < 0 || gg > 23) {
                gg = 0;
            }
            y[i] = t[gg];
            x[i] = ((x[i] + (3)) % 24) / 24;
//            x[i] /= 24;
        }

        List<Pair<Double, Double>> ans = GaussianMixture.calculate(x, 3189, 300, 2);
        System.out.println("mu: " + ans.get(0).getKey() + " sigma^2: " + ans.get(0).getValue());
        System.out.println("mu: " + ans.get(1).getKey() + " sigma^2: " + ans.get(1).getValue());


        for (int i = 0; i < 3189; i++) {
            x2[i] = x2[i] / 24 + 0.125;
        }
        plot.addLinePlot("tweet plot", Color.BLACK, x2, y);


        double[] x4 = Arrays.copyOf(x2, 3189);
        for (int i = 0; i < 3189; i++) {
//            if ((x4[i] + 1) < 1.1)
            x4[i] = x4[i] + 1;
        }
        plot.addLinePlot("tweet plot", Color.BLACK, x4, y);
        double[] x3 = Arrays.copyOf(x2, 3189);
        for (int i = 0; i < 3189; i++) {
//            if ((x3[i] - 1) > -0.15)
            x3[i] = x3[i] - 1;
        }
        plot.addLinePlot("tweet plot", Color.BLACK, x3, y);


        double[] g_y1 = new double[170];
        double[] g_y2 = new double[170];
        double[] g_x = new double[170];

        int i = 0;
        for (double p = -0.2; p < 1.5; p += 0.01) {
            g_x[i] = p;
            g_y1[i] = GaussianMixture.calcN(p, ans.get(0).getKey(), Math.sqrt(ans.get(0).getValue())) * 96;
            g_y2[i] = GaussianMixture.calcN(p, ans.get(1).getKey(), Math.sqrt(ans.get(1).getValue() - 0.001)) * 50;
            i++;
        }

        plot.addLinePlot("g1 plot", Color.RED, g_x, g_y1);
        plot.addLinePlot("g2 plot", Color.BLUE, g_x, g_y2);

        JFrame frame = new JFrame("a plot panel");
        frame.setSize(600, 600);
        frame.setContentPane(plot);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);


    }
}
