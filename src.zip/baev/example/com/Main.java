package baev.example.com;

import twitter4j.*;

public class Main {
    public static void main(String[] args) {
        Twitter twitter = new TwitterFactory().getInstance();
        try {
            ResponseList<Status> timeLine = twitter.getUserTimeline("neoxij");
            for (Status status : timeLine) {
                System.out.println("time: " + status.getCreatedAt()
                        + " off:" + status.getUser().getUtcOffset() + "Text: " + status.getText());
            }
        } catch (TwitterException e) {
            e.printStackTrace();
        }


        /*List<baev.example.com.User> userList = new ArrayList<>();
        TwitterStream twitterStream = new TwitterStreamFactory().getInstance();
        StatusListener statusListener = new StatusListener() {
            @Override
            public void onStatus(Status status) {
                //System.out.println("Status!");
                User u = status.getUser();
                if (u.getLang().equals("en") && u.getUtcOffset() != -1) {
                    userList.add(new baev.example.com.User(u.getId(), u.getScreenName(), u.getUtcOffset()));
                }
                if (userList.size() == 1000) {
                    for (baev.example.com.User user : userList) {
                        System.out.println(user.toString());
                    }
                    twitterStream.shutdown();
                }
            }

            @Override
            public void onDeletionNotice(StatusDeletionNotice statusDeletionNotice) {
                System.out.println("del notice!");
            }

            @Override
            public void onTrackLimitationNotice(int i) {
                System.out.println("Got track limitation notice:" + i);
            }

            @Override
            public void onScrubGeo(long l, long l1) {
                System.out.println("scrubGeo");
            }

            @Override
            public void onStallWarning(StallWarning stallWarning) {
                System.out.println("stallwarn");
            }

            @Override
            public void onException(Exception e) {
                System.out.println("ex!");
                e.printStackTrace();
            }
        };
        twitterStream.addListener(statusListener);
        twitterStream.sample("en");
        */
    }
}
