package baev.example.com;

import javafx.util.Pair;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class GaussianMixture {
    public static double calcN(double x, double mu, double sigma) {
        return 1.0 / (Math.sqrt(2.0 * Math.PI) * sigma) * Math.exp(-(Math.pow(x - mu, 2.0))
                / (2 * Math.pow(sigma, 2.0)));
    }

    public static List<Pair<Double, Double>> calculate(double[] times, int n, int iterations, int k) {
        double[] w = new double[k];
        double[] mu = new double[k];
        double[] sigma = new double[k];
        Arrays.fill(w, 0.5);
        mu[0] = 0.1;
        mu[1] = 0.8;
        Arrays.fill(sigma, 0.1);
        for (int id = 0; id < iterations; id++) {
            //System.out.println("EM iter #" + id);
            double[][] g = new double[n][k];
            for (int i = 0; i < n; i++) {
                double sum = 0;
                for (int j = 0; j < k; j++) {
                    sum += ((w[j]) * (calcN(times[i], mu[j], sigma[j])));
                }
                for (int j = 0; j < k; j++) {
                    g[i][j] = (w[j] * calcN(times[i], mu[j], sigma[j])) / (sum);
                }
            }
            for (int j = 0; j < k; j++) {
                double sum = 0;
                for (int i = 0; i < n; i++) {
                    sum += g[i][j];
                }
                w[j] = sum / n;
            }
            for (int j = 0; j < k; j++) {
                double sum = 0;
                for (int i = 0; i < n; i++) {
                    sum += g[i][j] * times[i];
                }
                mu[j] = sum / (n * w[j]);
            }
            for (int j = 0; j < k; j++) {
                double sum = 0;
                for (int i = 0; i < n; i++) {
                    sum += g[i][j] * Math.pow(times[i] - mu[j], 2);
                }
                sigma[j] = Math.sqrt(sum / (n * w[j]));
            }
        }
        List<Pair<Double, Double>> ans = new ArrayList<>();
        for (int i = 0; i < k; i++) {
            ans.add(new Pair<>(mu[i], Math.pow(sigma[i], 2)));
        }
        return ans;
    }
}
