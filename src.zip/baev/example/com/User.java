package baev.example.com;

public class User {
    private long id;
    private String screenName;
    private int utcOffset;

    public User(long id, String screenName, int utcOffset) {
        this.id = id;
        this.screenName = screenName;
        this.utcOffset = utcOffset;
    }

    @Override
    public String toString() {
        return id + " " + screenName + " " + utcOffset;
    }
}
