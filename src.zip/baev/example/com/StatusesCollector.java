package baev.example.com;

import twitter4j.*;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class StatusesCollector {
    public static void main(String[] args) throws IOException {
        BufferedReader in = new BufferedReader(new FileReader("Users.txt"));
        PrintWriter out = new PrintWriter("temp.txt");
        Twitter twitter = new TwitterFactory().getInstance();
        Paging paging = new Paging(1, 200);


        /*Set<String> s = new HashSet<>();
        for (int j = 0; j < 95898; j++) {
            String id = in.readLine().split(" ")[0];
            s.add(id);

        }
        System.out.println("S size: " + s.size());
        */

        //230!

        for (int j = 0; j < 180; j++) {
            in.readLine();
        }

        for (int i = 0; i < 50; i++) {
            System.out.println("User: " + i);
            String[] parts = in.readLine().split("\t");
            String userName = parts[1];
            String userId = parts[0];
            long offset = Long.valueOf(parts[3]);
            try {
                for (int j = 0; j < 2; j++) {
                    ResponseList<Status> timeLine = twitter.getUserTimeline(userName, paging);
                    for (Status status : timeLine) {
                        Date createdAt = status.getCreatedAt();
                        long time = createdAt.getTime() - TimeUnit.SECONDS.toMillis(14400) + (offset * 1000);
                        Date local = new Date(time);
                        String ans = userId + " " + local.toString()
                                + "$ " + status.getText().replaceAll("\n", " ").replaceAll("\r", " ");
                        out.println(ans);
                    }
//                        out.println();
                    paging = new Paging(j + 2, 200);
                }
            } catch (TwitterException e) {
                e.printStackTrace();
            }
        }

        in.close();
        out.close();
    }
}
