package baev.example.com;

import twitter4j.*;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

public class GetFromQuiz {
    public static void main(String[] args) throws IOException {
//        BufferedReader in = new BufferedReader(new FileReader("Users_name_chr.txt"));
//        PrintWriter out = new PrintWriter("temp.txt");
        BufferedReader in = new BufferedReader(new FileReader("temp.txt"));
        PrintWriter out = new PrintWriter("temp_out.txt");
        Twitter twitter = new TwitterFactory().getInstance();
        Paging paging = new Paging(1, 200);

        /*Map<String, String> m = new HashMap<>();
        for (int i = 0; i < 206; i++) {
            String s = in.readLine();
            String[] ss = s.split("\t");
            m.put(ss[0], s);
        }
        m.values().forEach(out::println);
        out.close();

        if (true) {
            return;
        }
        */

        /*Set<String> s = new HashSet<>();
        for (int j = 0; j < 95898; j++) {
            String id = in.readLine().split(" ")[0];
            s.add(id);

        }
        System.out.println("S size: " + s.size());
        */



        /*for (int j = 0; j < 170; j++) {
            in.readLine();
        }*/

        //261
        for (int i = 0; i < 26; i++) {
            System.out.print("User: " + i + " ");
            String[] parts = in.readLine().split("\t");
            String userName = parts[0];
            String chronotype = parts[1];
            System.out.println(userName);
            for (int j = 0; j < 1; j++) {
                ResponseList<Status> timeLine;
                try {
                    timeLine = twitter.getUserTimeline(userName);
                } catch (TwitterException e) {
                    System.out.println(e.toString());
                    continue;
                }
                if (timeLine == null || timeLine.isEmpty()) {
                    System.out.println("empty");
                    continue;
                }
                int offset = timeLine.get(0).getUser().getUtcOffset();
                long userId = timeLine.get(0).getUser().getId();
                String lang = timeLine.get(0).getUser().getLang();
                String location = timeLine.get(0).getUser().getLocation();
                out.println(userId + "\t" + userName + "\t" + chronotype + "\t" + offset + "\t" + lang + "\t" + location);
                out.flush();
                break;
                /*for (Status status : timeLine) {
                    Date createdAt = status.getCreatedAt();
                    long time = createdAt.getTime() - TimeUnit.SECONDS.toMillis(14400) + (28800 * 1000);
                    Date local = new Date(time);
                    String ans = status.getUser().getId() + " " + local.toString()
                            + " " + status.getText().replaceAll("\n", " ");
                    out.println(ans);
                }*/
//                        out.println();
                //paging = new Paging(j + 2, 200);
            }
        }

        in.close();
        out.close();
    }
}
